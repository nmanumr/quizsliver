(function () {
    'use strict';

    function loadLocalScript(url) {
        let s = document.createElement('script');
        s.src = chrome.extension.getURL(url);
        (document.head || document.documentElement).appendChild(s);
    }
    function loadTextScript(script) {
        let s = document.createElement('script');
        s.textContent = script;
        (document.head || document.documentElement).appendChild(s);
    }
    loadTextScript(`var extId = "${chrome.runtime.id}";`);
    loadLocalScript("extension.js");

}());
